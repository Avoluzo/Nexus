## Sobre o projeto

Nexus é uma plataforma online onde desenvolvedores de jogos indie podem publicar seus projetos. Jogadores podem doar quantias financeiras para apoiar aqueles projetos que consideram interessantes.

## Ferramentas utilizadas

![Java](https://img.shields.io/badge/Java-0D1117?style=for-the-badge&logo=openjdk&logoColor=FFFFFF)
![Spring](https://img.shields.io/badge/Spring-0D1117?style=for-the-badge&logo=Spring&logoColor=FFF)
![MySQL](https://img.shields.io/badge/MySQL-0D1117?style=for-the-badge&logo=mysql&logoColor=FFFFFF)
![Hibernate](https://img.shields.io/badge/Hibernate-0D1117?style=for-the-badge&logo=Hibernate&logoColor=FFFFFF)
![FlyWay](https://img.shields.io/badge/Flyway-0D1117?style=for-the-badge&logo=flyway&logoColor=FFFFFF)
![JWT](https://img.shields.io/badge/Jwt-0D1117?style=for-the-badge&logo=jwt&logoColor=FFFFFF)


## Features

1. ***Cadastrar conta***: Inserindo os dados necessários é possível criar uma conta na plataforma
2. ***Alterar informações da conta***: Alguns dos dados da conta podem ser trocados
3. ***Deletar conta***: A conta pode ser deletada da plataforma
   
4. ***Criar projeto***: Inserindo os dados necessários é possível criar projetos
5. ***Ver projetos***: É possível ver projetos que já foram criados
6. ***Alterar informações do projeto***: Alguns dos dados dos projetos podem ser trocados
7. ***Deletar projeto***: Projetos podem ser deletados

## Autor
Gabriel Viegas Dantas
  - gvd2808@gmail.com
