package br.com.Nexus.Nexus.domain.account;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Transactional
    public Account registerAccount(RegisterAccountDTO registerAccountDTO) {
        Account account = registerAccountDTO.convertRegisterAccountDTO(registerAccountDTO);
        accountRepository.save(account);

        return account;
    }

    @Transactional
    public Account updateAccount(UpdateAccountDTO updateAccountDTO) {
        Account account = accountRepository.getReferenceById(updateAccountDTO.id());
        updateAccountInformation(account, updateAccountDTO);

        return account;
    }

    @Transactional
    public void deleteAccount(DeleteAccountDTO deleteAccountDTO) {
        Account account = accountRepository.getReferenceById(deleteAccountDTO.id());
        accountRepository.deleteById(account.getId());
    }

    private void updateAccountInformation(Account account, UpdateAccountDTO updateAccountDTO) {
        if (updateAccountDTO.name() != null) {
            account.setName(updateAccountDTO.name());
        }
        if (updateAccountDTO.email() != null) {
            account.setEmail(updateAccountDTO.email());
        }
        if (updateAccountDTO.password() != null) {
            account.setPassword(updateAccountDTO.password());
        }
    }
}
