package br.com.Nexus.Nexus.domain.account;

import jakarta.validation.constraints.NotNull;

public record DeleteAccountDTO(

        @NotNull
        Long id
) {
}
