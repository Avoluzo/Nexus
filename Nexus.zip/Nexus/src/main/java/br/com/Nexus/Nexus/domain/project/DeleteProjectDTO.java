package br.com.Nexus.Nexus.domain.project;

import jakarta.validation.constraints.NotNull;

public record DeleteProjectDTO(

        @NotNull
        Long id
) {
}
