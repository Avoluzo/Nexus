package br.com.Nexus.Nexus.domain.account;

import jakarta.validation.constraints.NotNull;

public record DetailetAccountDTO(

        Long id,

        String name,

        String email,

        String password
) {

    public DetailetAccountDTO(Account account) {
        this(account.getId(), account.getName(), account.getEmail(), account.getPassword());
    }
}
