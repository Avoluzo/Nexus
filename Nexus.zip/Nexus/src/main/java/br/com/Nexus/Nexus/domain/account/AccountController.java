package br.com.Nexus.Nexus.domain.account;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/register")
    public ResponseEntity registerAccount(@RequestBody @Valid RegisterAccountDTO registerAccountDTO, UriComponentsBuilder componentsBuilder) {
        Account account = accountService.registerAccount(registerAccountDTO);

        URI uri = componentsBuilder.path("/account/{id}").buildAndExpand(account.getId()).toUri();

        return ResponseEntity.created(uri).body(new DetailetAccountDTO(account));
    }

    @PutMapping("/update")
    @Transactional
    public ResponseEntity updateAccount(@RequestBody @Valid UpdateAccountDTO updateAccountDTO) {
        Account account = accountService.updateAccount(updateAccountDTO);

        return ResponseEntity.ok(new DetailetAccountDTO(account));
    }

    @DeleteMapping("/delete")
    public ResponseEntity deleteAccount(@RequestBody @Valid DeleteAccountDTO deleteAccountDTO) {
        accountService.deleteAccount(deleteAccountDTO);

        return ResponseEntity.noContent().build();
    }
}
