package br.com.Nexus.Nexus.domain.account;

import jakarta.validation.constraints.NotBlank;

public record RegisterAccountDTO(

        @NotBlank
        String name,

        @NotBlank
        String email,

        @NotBlank
        String password
) {

    public Account convertRegisterAccountDTO(RegisterAccountDTO registerAccountDTO) {
        return new Account(registerAccountDTO);
    }
}
