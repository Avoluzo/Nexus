package br.com.Nexus.Nexus.domain.project;

import br.com.Nexus.Nexus.domain.account.Account;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = "id")
@Entity(name = "Project")
@Table(name = "projects")
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    private BigDecimal financialTarget;

    @ManyToOne
    @Transient
    private Account account;

    public Project(CreateProjectDTO createProjectDTO) {
        this.name = createProjectDTO.name();
        this.description = createProjectDTO.description();
        this.financialTarget = createProjectDTO.financialTarget();
    }
}
