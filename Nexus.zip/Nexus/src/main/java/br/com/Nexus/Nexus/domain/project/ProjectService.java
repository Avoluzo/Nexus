package br.com.Nexus.Nexus.domain.project;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Transactional
    public Project createProject(CreateProjectDTO createProjectDTO) {
        Project project = createProjectDTO.convertCreateProjectDTO(createProjectDTO);
        projectRepository.save(project);

        return project;
    }

    public List<DetailedProjectDTO> getProjects() {
        return projectRepository.findAll()
                .stream()
                .map(DetailedProjectDTO::new)
                .collect(Collectors.toList());
    }


    @Transactional
    public Project updateProject(UpdateProjectDTO updateProjectDTO) {
        Project project = projectRepository.getReferenceById(updateProjectDTO.id());
        updateProjectInformation(project, updateProjectDTO);

        return project;
    }

    @Transactional
    public void deleteProject(DeleteProjectDTO deleteProjectDTO) {
        Project project = projectRepository.getReferenceById(deleteProjectDTO.id());
        projectRepository.deleteById(project.getId());
    }

    private void updateProjectInformation(Project project, UpdateProjectDTO updateProjectDTO) {
        if (updateProjectDTO.description() != null) {
            project.setDescription(updateProjectDTO.description());
        }
        if (updateProjectDTO.financialTarget() != null) {
            project.setFinancialTarget(updateProjectDTO.financialTarget());
        }
    }

}
