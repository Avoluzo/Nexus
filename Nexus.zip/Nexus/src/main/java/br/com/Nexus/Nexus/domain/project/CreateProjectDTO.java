package br.com.Nexus.Nexus.domain.project;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record CreateProjectDTO(

        @NotBlank
        String name,

        @NotBlank
        String description,

        @NotNull
        BigDecimal financialTarget
) {
    public Project convertCreateProjectDTO(CreateProjectDTO createProjectDTO) {
        return new Project(createProjectDTO);
    }
}
