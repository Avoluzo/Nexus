package br.com.Nexus.Nexus.domain.account;

import br.com.Nexus.Nexus.domain.project.Project;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = "id")
@Entity(name = "Account")
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String email;

    private String password;

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Transient
    List<Project> projects = new ArrayList<>();

    public Account(RegisterAccountDTO registerAccountDTO) {
        this.name = registerAccountDTO.name();
        this.email = registerAccountDTO.email();
        this.password = registerAccountDTO.password();
    }
}
