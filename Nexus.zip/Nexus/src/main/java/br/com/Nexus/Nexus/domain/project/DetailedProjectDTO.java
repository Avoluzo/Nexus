package br.com.Nexus.Nexus.domain.project;

import java.math.BigDecimal;

public record DetailedProjectDTO(

        Long id,

        String name,

        String description,

        BigDecimal financialTarget
) {

    public DetailedProjectDTO(Project project) {
        this(project.getId(), project.getName(), project.getDescription(), project.getFinancialTarget());
    }
}
