package br.com.Nexus.Nexus.domain.project;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account/project")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping("/create_project")
    public ResponseEntity createProject(@RequestBody @Valid CreateProjectDTO createProjectDTO) {
        Project project = projectService.createProject(createProjectDTO);

        return ResponseEntity.ok().build();
    }

    @GetMapping("/get_projects")
    public ResponseEntity<List<DetailedProjectDTO>> getProjects() {
        List<DetailedProjectDTO> projects = projectService.getProjects();

        return ResponseEntity.ok(projects);
    }

    @PutMapping("/update_project")
    public ResponseEntity updateProject(@RequestBody @Valid UpdateProjectDTO updateProjectDTO) {
        Project project = projectService.updateProject(updateProjectDTO);

        return ResponseEntity.ok(new DetailedProjectDTO(project));
    }

    @DeleteMapping("/delete_project")
    public ResponseEntity deleteProject(@RequestBody @Valid DeleteProjectDTO deleteProjectDTO) {
        projectService.deleteProject(deleteProjectDTO);

        return ResponseEntity.noContent().build();
    }

}
