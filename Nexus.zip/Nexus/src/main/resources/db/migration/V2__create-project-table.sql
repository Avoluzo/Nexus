
CREATE TABLE projects
(
    id bigint NOT NULL auto_increment,
    name VARCHAR(150) NOT NULL UNIQUE,
    description VARCHAR(255) NOT NULL,
    financial_target DECIMAL(5,2) NOT NULL,

    PRIMARY KEY(id)
);